const os=require("os");
console.log(os.freemem())
console.log(os.hostname());
console.log(os.totalmem());
console.log(os.arch());
console.log(os.platform());
console.log(os.cpus());




