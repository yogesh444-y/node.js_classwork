const fs=require("fs");
fs.readFile("message.txt",(err,data)=>{
    if(err){
        console.log(err);
        
    }else{
        console.log(data.toString());
        
    }
 })
fs.writeFile("message.txt","hello",(err)=>{
    if(err){
        console.log(err);
        
    }else{
        console.log("file created");
        
    }
})
fs.appendFile("message.txt","world",(err)=>{
    if(err){
        console.log(err);
        
    }else{
        console.log("appended");
        
    }
})
fs.unlink("message.txt",(err)=>{
    if(err){
        console.log(err);
        
    }else{
        console.log("deleted");
        
    }
})